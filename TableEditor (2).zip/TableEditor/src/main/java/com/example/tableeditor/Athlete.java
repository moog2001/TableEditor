package com.example.tableeditor;

import javafx.scene.paint.Color;

public class Athlete {
    String FirstName;
    String LastName;
    String Sport;
    Integer Years;
    Boolean isVegetarian;
    Color FavColor;

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getSport() {
        return Sport;
    }

    public void setSport(String sport) {
        Sport = sport;
    }

    public Integer getYears() {
        return Years;
    }

    public void setYears(Integer years) {
        Years = years;
    }

    public Boolean getVegetarian() {
        return isVegetarian;
    }

    public void setVegetarian(Boolean vegetarian) {
        isVegetarian = vegetarian;
    }

    public Color getFavColor() {
        return FavColor;
    }

    public void setFavColor(Color favColor) {
        FavColor = favColor;
    }


    public Athlete(String firstName, String lastName, String sport, Integer years, Boolean isVegetarian, Color favColor) {
        FirstName = firstName;
        LastName = lastName;
        Sport = sport;
        Years = years;
        this.isVegetarian = isVegetarian;
        FavColor = favColor;
    }
}
